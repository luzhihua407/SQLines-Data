SQLines Data transfers data and schema between databases.
Copyright (c) 2017 SQLines. All rights reserved.

No installation required.

 - ./sqldata - Command line tool (run to see options)