SQLines Data transfers data and schema between databases.
Copyright (c) 2014 SQLines. All rights reserved.

No installation required.

 - sqldataw.exe - GUI tool
 - sqldata.exe - Command line tool (run to see options)